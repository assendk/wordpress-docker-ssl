<?php
/**
 * Plugin Name: Disable SSL Verification
 * Description: Temporarily disables SSL verification for outgoing WordPress requests.
 * Version: 1.0
 * Author: Your Name
 */

add_filter('http_request_args', function ($args) {
    $args['sslverify'] = false;
    return $args;
}, 10, 1);
